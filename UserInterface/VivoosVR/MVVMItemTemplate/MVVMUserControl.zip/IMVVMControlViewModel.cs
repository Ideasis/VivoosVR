﻿using Core.MVVM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace $rootnamespace$
{
    public interface $safeitemname$ : IControlViewModel
    {
    }
}
